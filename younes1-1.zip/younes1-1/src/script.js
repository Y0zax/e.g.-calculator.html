let display = document.getElementById('display');

function clearDisplay() {

  display.value = '';

}

function appendToDisplay(value) {

  display.value += value;

}

function calculate() {

  let expression = display.value;

  if (expression === '1+1') {

    display.value = 'I love you';

  } else {

    // Handle other calculations here (optional)

    display.value = eval(expression);

  }

}